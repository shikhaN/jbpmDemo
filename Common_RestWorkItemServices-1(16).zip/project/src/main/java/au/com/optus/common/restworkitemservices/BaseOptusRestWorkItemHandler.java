package au.com.optus.common.restworkitemservices;

import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemManager;
import org.jbpm.process.workitem.rest.RESTWorkItemHandler;
import org.jbpm.workflow.instance.WorkflowRuntimeException;
import org.jbpm.process.workitem.rest.RESTServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.logging.Level;



//----------------------------------------------------------
// This Class handles Retry Mechanism in Generic Renainssance Process for REST API calls
public class BaseOptusRestWorkItemHandler extends RESTWorkItemHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(BaseOptusRestWorkItemHandler.class);

    private int maxRetries = 3;
    private long delayBetweenRetries = 5000;
    private long maxExecutionTime = 5000;


    public BaseOptusRestWorkItemHandler() {
        super();
    }
    

    @Override
    public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
        logWorkItemDetails(workItem);
        int retryCount = 0;
        long startTime = System.currentTimeMillis();

        while (retryCount < maxRetries) {
            try {
                super.executeWorkItem(workItem, manager);
                return;
            } catch (Exception e) {
                long elapsedTime = System.currentTimeMillis() - startTime;
                if (elapsedTime > maxExecutionTime) {
                    handleException(e);
                    return;
                }

                handleLogs("executeWorkItem", "retrying request: retryCount = " + retryCount);
                retryCount++;
                try {
                    handleLogMessage("executeWorkItem", "sleeping for " + delayBetweenRetries + "(msec)");
                    Thread.sleep(delayBetweenRetries);
                } catch (InterruptedException ie) {
                    handleLogMessage("executeWorkItem", ie.getMessage());
                    Thread.currentThread().interrupt();
                }
            }
        }
        handleException(new RuntimeException("Maximum retries reached."));
    }
    
    @Override
    public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
        handleLogs("abortWorkItem", workItem.getName());
        super.abortWorkItem(workItem, manager);
    }
    
    protected void handleErrorLogs(String methodName, String message)
    {
        //could do equiv in log4j.properties
        logger.error(this.getClass().getName() + "::" + methodName + "()" + message);
    }    
    
    protected void handleLogs(String methodName, String message)
    {
        //could do equiv in log4j.properties
        logger.info(this.getClass().getName() + "::" + methodName + "()" + message);
    }


    protected void handleLogMessage(String methodName, String message)
    {
        //could do equiv in log4j.properties
        logger.info(this.getClass().getName() + "::" + methodName + "()" + message);
    }    

    protected void handleException(Exception e)
    {
        handleLogs("handleException", "entering");
        System.err.println("WorkItemHandler error: " + e.getMessage());
        e.printStackTrace();
        
        throw new RuntimeException(e);
    }
    
    protected void logWorkItemDetails(WorkItem workItem) {
        handleLogs("logWorkItemDetails", "entering");
        handleLogs("logWorkItemDetails", "--------------------------------");
        handleLogs("logWorkItemDetails", "Executing work item with details: ");
        handleLogs("logWorkItemDetails", " - WorkItem ID: " +  workItem.getId());
        handleLogs("logWorkItemDetails", " - WorkItem Name: " +  workItem.getName());
        handleLogs("logWorkItemDetails", " - Parameters: " +  workItem.getParameters());
    }    
}

