package au.com.optus.common.restworkitemservices;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.kie.api.runtime.process.ProcessContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.SimpleDateFormat;
import java.util.Date;


import java.util.HashMap;

//------------------------------------
public class ProcessContextStatusUtil {

    private static final Logger logger = LoggerFactory.getLogger(ProcessContextStatusUtil.class);
    private static final ObjectMapper mapper = new ObjectMapper(); 

    //------------------------------------
    public String createStatusJson(String spaceId, String projectName, String taskName, ProcessContext kcontext, String state, HashMap<String, Object> additionalAttributes) {
        logger.info("ProcessContextStatusUtil - Collecting data for: {}: {}: {}: State: {}", spaceId, projectName, taskName, state);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String timestampStr  = dateFormat.format(new Date());

        ObjectNode jsonObject = mapper.createObjectNode();
        jsonObject.put("Space", spaceId)
                  .put("Project", projectName)
                  .put("Task", taskName)
                  .put("InstanceID", kcontext.getProcessInstance().getId())
                  .put("ProcessID", kcontext.getProcessInstance().getProcessId())
                  .put("State", state)
                  .put("Timestamp", timestampStr);

        additionalAttributes.forEach((key, value) -> {
            if (value instanceof String) jsonObject.put(key, (String) value);
            else if (value instanceof Integer) jsonObject.put(key, (Integer) value);
            else if (value instanceof Boolean) jsonObject.put(key, (Boolean) value);
            else jsonObject.putPOJO(key, value); // Fallback for other types
        });

        try {
            return mapper.writeValueAsString(jsonObject);
        } catch (Exception e) {
            logger.error("ProcessContextStatusUtil - Exception thrown during JSON serialization: {}", e.getMessage());
            return null;
        }
    }

    //------------------------------------
    public String beforeRestWorkItemCall(String spaceId, String projectName, String taskName, ProcessContext kcontext) {
        HashMap<String, Object> attributes = new HashMap<>();
                System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::SHIKHA1234");
        attributes.put("correlationId", getVariable(kcontext, "correlationId"));
        attributes.put("configKey", getVariable(kcontext, "configKey"));
        attributes.put("configPath", getVariable(kcontext, "configPath"));
        attributes.put("configName", getVariable(kcontext, "configName"));
        attributes.put("jsonData", getVariable(kcontext, "jsonData"));
        attributes.put("patchData", getVariable(kcontext, "patchData"));
        attributes.put("postData", getVariable(kcontext, "postData"));
         System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::1");
    //    System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::correlationId="+getVariable(kcontext, "correlationId").toString());
            //  System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::2");
        System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::configKey="+getVariable(kcontext, "configKey").toString());
              System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::3");
        System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::configPath="+getVariable(kcontext, "configPath").toString());
              System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::4");
     //   System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::configName="+getVariable(kcontext, "configName").toString());
              System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::5");
    //    System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::jsonData="+getVariable(kcontext, "jsonData").toString());
              System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::6");
      //  System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::patchData="+getVariable(kcontext, "patchData").toString());
              System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::7");
     //   System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::postData="+getVariable(kcontext, "postData").toString());
       //       System.out.println("ProcessContextStatusUtil::beforeRestWorkItemCall::8");
      

        return createStatusJson(spaceId, projectName, taskName, kcontext, "starting", attributes);
    }

    //------------------------------------
    public String afterRestWorkItemCall(String spaceId, String projectName, String taskName, ProcessContext kcontext) {
        HashMap<String, Object> attributes = new HashMap<>();
            System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::SHIKHAasdf");
        attributes.put("correlationId", getVariable(kcontext, "correlationId"));
        attributes.put("response", getVariable(kcontext, "response"));
        attributes.put("httpStatus", getVariable(kcontext, "httpStatus"));
        attributes.put("statusMsg", getVariable(kcontext, "statusMsg"));

 System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::1");
  System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::correlationId="+getVariable(kcontext, "correlationId").toString());
   System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::2");
        System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::response="+getVariable(kcontext, "response").toString());
           System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::3");
       // System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::httpStatus="+getVariable(kcontext, "httpStatus").toString());
      //  System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::configName="+getVariable(kcontext, "configName").toString());
           System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::4");
        System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::statusMsg="+getVariable(kcontext, "statusMsg").toString());
        System.out.println("ProcessContextStatusUtil::afterRestWorkItemCall::5");
        
        return createStatusJson(spaceId, projectName, taskName, kcontext, "finished", attributes);
    }
    
    //-------------updated by shikha traceId and calling_TaskName added-----------------------
   public String errorRestWorkItemCall(String errorException, String statusData,String traceId, String calling_TaskName, ProcessContext kcontext) {
        System.out.println("shikha errorRestWorkItemCall called");
        ObjectNode jsonObject = mapper.createObjectNode();
		jsonObject.put("name", getVariable(kcontext, "taskNameVar").toString());
        jsonObject.put("result", "{"+errorException+"}");
		jsonObject.put("runner_id", kcontext.getProcessInstance().getId());
        jsonObject.put("status", statusData);
		jsonObject.put("trace_id", traceId);
		
		 System.out.println("shikha errorRestWorkItemCall called $$ traceId = "+getVariable(kcontext, "trace_id").toString());
		 System.out.println("shikha errorRestWorkItemCall called $$ taskNameVar = "+getVariable(kcontext, "taskNameVar").toString());
        try {
            return mapper.writeValueAsString(jsonObject);
        } catch (Exception e) {
            logger.error("ProcessContextStatusUtil::errorRestWorkItemCall() - Exception thrown during JSON serialization: {}", e.getMessage());
            return null;
        }
    }
    //------------------------------------
    public void flushProcessContextValues(ProcessContext kcontext) {
        logger.info("ProcessContextStatusUtil::flushProcessContextValues() - flushing values");
        kcontext.setVariable("configKey","");
        kcontext.setVariable("jsonData","");
        kcontext.setVariable("configPath","");
        kcontext.setVariable("configName","");
        kcontext.setVariable("taskName","");
        kcontext.setVariable("patchdata","");
        kcontext.setVariable("statusData","");
        kcontext.setVariable("postData","");
    }

    //------------------------------------
    private <T> T getVariable(ProcessContext kcontext, String variableName) {
        return (T) kcontext.getVariable(variableName); // Unchecked cast ??
    }
}