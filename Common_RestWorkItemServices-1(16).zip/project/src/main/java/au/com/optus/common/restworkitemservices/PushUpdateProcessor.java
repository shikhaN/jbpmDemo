package au.com.optus.common.restworkitemservices;

import com.fasterxml.jackson.core.JsonProcessingException;

import org.kie.api.runtime.process.ProcessContext;
import org.kie.internal.process.CorrelationKey;
import org.jbpm.process.instance.impl.ProcessInstanceImpl;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.KieSession;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.logging.Level;


//-------------------------------------------------------------------
public class PushUpdateProcessor {

    private static final Logger logger = LoggerFactory.getLogger(PushUpdateProcessor.class);

    private ProcessContext kcontext = null;
    private String businessProcessRef = "";  //business process id
    private String configKey = "";             //json config reference 

    //-------------------------------------------------------------------
    public PushUpdateProcessor(ProcessContext kcontext, String businessProcessRef, String configKey ) {
        System.out.println("shikha PushUpdateProcessor constructor");
        this.kcontext = kcontext;
        this.businessProcessRef = businessProcessRef;
        this.configKey = configKey;
         System.out.println("shikha PushUpdateProcessor valuesbusinessProcessRef="+businessProcessRef+", configkey="+configKey);
    }

    // called in ErrorHandlerProcess.bpmn
   public void callErrorPushUpdate(String statusData) throws RuntimeException {
        System.out.println("shikha called callErrorPushUpdate ");
        try {
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("configKey", configKey);
            parameters.put("jsonData", statusData);
            parameters.put("postData", statusData);
            
            logger.info(this.getClass().getName() + "::callErrorPushUpdate() - configKey = " + configKey);
            logger.info(this.getClass().getName() + "::callErrorPushUpdate() - jsonData/statusData = " + statusData);
            logger.info(this.getClass().getName() + "::callErrorPushUpdate() - postData = " + statusData);
            
              System.out.println("shikha called callErrorPushUpdate vars="+businessProcessRef+", configKey="+configKey+" , statusdata="+statusData);
            kcontext.getKieRuntime().startProcess(businessProcessRef,parameters);              
        }
        catch (Exception e)
        {
            logger.info(this.getClass().getName() + "::callTaskPushUpdate()" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }    

    //-------------------------------------------------------------------
    //Called in Generic Renaissance process - GenericRestProcess.bpmn
    public void callTaskPushUpdate(String statusData) throws RuntimeException {
        
        logger.info(this.getClass().getName() + "::callTaskPushUpdate(statusData) - entered");
        
        try {
            Map<String, Object> statusInfo = new HashMap<>();
            statusInfo.put("postdata", statusData);
            
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("configKey", configKey);
            parameters.put("jsonData", statusInfo);

            
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - configKey = " + configKey);
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - postData = " + statusData);
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - jsonData = " + statusData);
             logger.info(this.getClass().getName() + "::callTaskPushUpdate() -statusData- businessProcessRef = " + businessProcessRef);
            
            
            kcontext.getKieRuntime().startProcess(businessProcessRef,parameters);              
        }
        catch (Exception e)
        {
            logger.info(this.getClass().getName() + "::callTaskPushUpdate(statusData)" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }

        logger.info(this.getClass().getName() + "::callTaskPushUpdate(statusData) - exited");
    }    
}