package au.com.optus.common.restworkitemservices;

import org.kie.api.runtime.process.ProcessContext;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.process.WorkflowProcessInstance;
import org.jbpm.workflow.instance.impl.WorkflowProcessInstanceImpl;
import org.jbpm.process.core.context.variable.VariableScope;
import org.jbpm.process.instance.context.variable.VariableScopeInstance;

import au.com.optus.common.restworkitemservices.MapToJsonProcessor;

import java.util.Map;
import java.util.LinkedHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Class for Printing All kContext Variable
public class ProcessContextPrinter {
    
    private static final Logger logger = LoggerFactory.getLogger(ProcessContextPrinter.class);

    public static void printAllVariables(String processName, ProcessContext kcontext) {
        
        logger.info("=====================================");
        logger.info(processName + "::printAllVariables()");
        logger.info("ProcessName - " + processName);
        

        
        try {
            ProcessInstance processInstance = kcontext.getProcessInstance();
            long processInstanceId = processInstance.getId();
            logger.info("processInstanceId - " + processInstanceId);
            logger.info("------------------------------------");
            
            if (processInstance instanceof WorkflowProcessInstanceImpl) {
                WorkflowProcessInstanceImpl workflowProcessInstance = (WorkflowProcessInstanceImpl) processInstance;
                VariableScopeInstance variableScopeInstance = (VariableScopeInstance)
                    workflowProcessInstance.getContextInstance(VariableScope.VARIABLE_SCOPE);
    
                Map<String, Object> variables = variableScopeInstance.getVariables();
    
                if (variables != null && !variables.isEmpty()) {
                    logger.info("Variables in kcontext:");
                    for (Map.Entry<String, Object> entry : variables.entrySet()) {
                        if(entry.getValue() instanceof LinkedHashMap) {
                            logger.info(entry.getKey() + " is a LinkedHashMap ");
                            MapToJsonProcessor mapToJson = new MapToJsonProcessor();
                            String entryValue = mapToJson.convertMapToJson((Map)entry.getValue());
                            logger.info(entry.getKey() + " = " + entryValue);
                        }
                        else {
                            logger.info(entry.getKey() + " = " + (entry.getValue()).toString());
                        }
                    }
                } else {
                    logger.error("No variables found in kcontext.");
                }
            } else {
                logger.error("Process instance is not a WorkflowProcessInstance.");
            }
            
            
            


        }
        catch(Exception e) {
            logger.error("ProcessContextPrinter::printAllVariables() - exception throw and caught" + e.getMessage());
        }
        logger.info("=====================================");
    }
}