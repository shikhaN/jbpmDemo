package au.com.optus.common.restworkitemservices;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.*; 
import org.json.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class JsonToMapProcessor {

   private static final Logger logger = LoggerFactory.getLogger(JsonToMapProcessor.class);
   private Map<String, Object> dataMap;

public JsonToMapProcessor() throws Exception
{
    
}
   //---------------------
   public JsonToMapProcessor(String jsonData) throws Exception {
       logger.info("JsonToMapProcessor::JsonToMapProcessor() - jsonData = " + jsonData);

       logger.info("JsonToMapProcessor::JsonToMapProcessor() leaving");
   }
   
  
   // Reading and Returning Helix Payload - Renaissance NTU ZTP
   //added by Shikha
   public String ReadHelixPayload(String jsonPayload, String jsonKey) throws Exception
   {
        System.out.println("ReadHelixPayload::helix payload="+jsonPayload);
         String jsonKeyValue="";
        try{
         String helixpy=jsonPayload.replace("=", "\":\"");
          helixpy=helixpy.replace(",", "\",\"");
          helixpy=helixpy.replace("\"[{", "[{\"");
          helixpy=helixpy.replace("{c", "{\"c");
          helixpy=helixpy.replace("}]}]", "\"}]}]");
          helixpy=helixpy.replace("[{d", "[{\"d");
          helixpy=helixpy.replace("\" ", "\"");
               
         String jsonHelixDataString=helixpy.trim();
          System.out.println("helix payload="+jsonHelixDataString);
          ObjectMapper mapper = new ObjectMapper();
          JsonNode actualObj = mapper.readTree(jsonHelixDataString);
          JsonNode jsonNode1 = actualObj.get("ce-ntu-manager:ntu-manager");//read main json 
          System.out.println("ce-ntu-manager:ntu-manager="+jsonNode1);
       
        JsonNode jsonNode2 = jsonNode1.findValue(jsonKey); //read json key value
        jsonKeyValue=jsonNode2.toString().replace("\"", "");
        System.out.println(jsonKey+" = "+jsonKeyValue);
       if(jsonKeyValue.equals(null)||(jsonKeyValue==null)||(jsonKeyValue=="")||jsonKeyValue.equals(""))
		{
		 System.out.println(jsonKey+" can not be null");
         throw new au.com.optus.common.optuscustomexceptions.OptusPushUpdateException(jsonKey+" can not be null/blank");
		}
         
        }catch(Exception e)
        {
            System.out.println("common::RestWorkItemServices::JsonToMapProcessor::ReadHelixPayload::exception e="+e);
            throw new au.com.optus.common.optuscustomexceptions.OptusPushUpdateException(e.getMessage());
        }
        return jsonKeyValue;
       
       
   }
   
   // Reading and Returning qTrac Payload - Renaissance NTU ZTP   
   //added by Shikha
   public String ReadQtracPayload(String jsonPayload, String jsonKey) throws Exception
   {
         String qtracpy=jsonPayload.replace("=", "\":\"");
         qtracpy=qtracpy.replace(",", "\",\"");
         qtracpy=qtracpy.replace("{", "{\"");
         qtracpy=qtracpy.replace("}", "\"}");
         qtracpy=qtracpy.replace("\" ", "\"");
         
               
         String jsonQtracDataString=qtracpy.trim();
          System.out.println("qtrac payload="+jsonQtracDataString);
          ObjectMapper mapper = new ObjectMapper();
          JsonNode actualObj = mapper.readTree(jsonQtracDataString);
          JsonNode jsonNode = actualObj.get(jsonKey);  //read json key value
       
        String jsonKeyValue=jsonNode.toString().replace("\"", "");
        System.out.println(jsonKey+" = "+jsonKeyValue);
        return jsonKeyValue;
       
       
   }
   
   //It is used in JsonNodeProcessor Class   
    public List<Object> getValuesForKeyPath(String keyPath) {
        logger.info("JsonToMapProcessor::getValuesForKeyPath() - keyPath = " + keyPath);
        List<Object> results = new ArrayList<>();
        if (dataMap != null && !dataMap.isEmpty()) {
            String[] parts = keyPath.split("\\.");
            getValuesFromMapForKeyPath(dataMap, parts, 0, results);
        }
        logger.info("JsonToMapProcessor::getValuesForKeyPath() - results = " + results);
        return results;
    }
    
   // called in method getValuesForKeyPath
    private void getValuesFromMapForKeyPath(Map<String, Object> map, String[] keyParts, int depth, List<Object> results) {
        Object value = map.get(keyParts[depth]);
    
        if (value == null) return;
    
        // If we reached the end of the key path, add the found value to results
        if (depth == keyParts.length - 1) {
            results.add(value);
        } else {
            // If value is another map, do a recursive call
            if (value instanceof Map) {
                getValuesFromMapForKeyPath((Map<String, Object>) value, keyParts, depth + 1, results);
            }
    
            // If value is a list, iterate over it
            if (value instanceof List) {
                for (Object listItem : (List<?>) value) {
                    if (listItem instanceof Map) {
                        getValuesFromMapForKeyPath((Map<String, Object>) listItem, keyParts, depth + 1, results);
                    }
                }
            }
        }
    }
}
