package au.com.optus.common.eventlisteners;

import org.kie.api.event.process.*;

public class OptusBaseProcessEventListener extends DefaultProcessEventListener {
    

    @Override
    public void beforeProcessStarted(ProcessStartedEvent event) {
        // Custom logic before a process starts
    }

    @Override
    public void afterProcessStarted(ProcessStartedEvent event) {
        // Custom logic after a process starts
    }

    @Override
    public void beforeProcessCompleted(ProcessCompletedEvent event) {
        // Custom logic before a process completes
    }

    @Override
    public void afterProcessCompleted(ProcessCompletedEvent event) {
        // Custom logic after a process completes
    }

    @Override
    public void beforeNodeTriggered(ProcessNodeTriggeredEvent event) {
        // Custom logic before a node is triggered
    }

    @Override
    public void afterNodeTriggered(ProcessNodeTriggeredEvent event) {
        // Custom logic after a node is triggered
    }

    @Override
    public void beforeNodeLeft(ProcessNodeLeftEvent event) {
        // Custom logic before leaving a node
    }

    @Override
    public void afterNodeLeft(ProcessNodeLeftEvent event) {
        // Custom logic after leaving a node
    }

    @Override
    public void beforeVariableChanged(ProcessVariableChangedEvent event) {
        // Custom logic before a process variable changes
    }

    @Override
    public void afterVariableChanged(ProcessVariableChangedEvent event) {
        // Custom logic after a process variable changes
    }

}