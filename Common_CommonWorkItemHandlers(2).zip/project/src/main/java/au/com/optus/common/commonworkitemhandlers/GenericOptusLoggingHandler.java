package au.com.optus.common.commonworkitemhandlers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemHandler;
import org.kie.api.runtime.process.WorkItemManager;

public class GenericOptusLoggingHandler implements WorkItemHandler {

    private static final Logger logger = LoggerFactory.getLogger(GenericOptusLoggingHandler.class);

    @Override
    public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
        // Log work item details
        logger.error("=====================================");
        logger.error("Executing work item with ID: " + workItem.getId());
        logger.error("Work item name: " + workItem.getName());
        logger.error("Work item parameters: " + workItem.getParameters());
        String message = (String) workItem.getParameters().get("Message");
        
        logger.error("message: " + message);
        logger.error("=====================================");

        // Complete the work item immediately after logging
        manager.completeWorkItem(workItem.getId(), null);
    }

    @Override
    public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
        // Log the abortion of the work item
        logger.error("Aborting work item with ID: " + workItem.getId());

        // Complete the work item if it's being aborted
        manager.completeWorkItem(workItem.getId(), null);
    }
}