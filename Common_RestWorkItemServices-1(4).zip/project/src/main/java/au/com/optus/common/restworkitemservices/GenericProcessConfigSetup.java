package au.com.optus.common.restworkitemservices;

import org.kie.api.runtime.process.ProcessContext;
import org.kie.api.runtime.process.ProcessInstance;
import au.com.optus.common.restworkitemservices.ProcessContextStatusUtil;
import au.com.optus.common.restworkitemservices.ProcessContextPrinter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//---------------------------------------------
public class GenericProcessConfigSetup {
    
    private static final Logger logger = LoggerFactory.getLogger(GenericProcessConfigSetup.class);

    private ProcessContext kcontext = null;
    private String pamSpace = null;
    private String pamProject = null;    
    private String configKey = null;
    private String configPath = null;
    private String configName = null; 
    private String jsonData = null; 
    private String deviceName =  null;
    
    private String patchJsonData = "{\n" +
            "    \"ce-ntu-manager:ntu-manager\": \n" +
            "        {\n" +
        	" 			\"provisoning-stage\": \"prechecks-passed\"\n" +
            "        }\n" +
            "}";
        

    //---------------------------------------
    public GenericProcessConfigSetup(ProcessContext kcontext, String pamSpace, String pamProject, String configKey, String jsonData) {
        this.kcontext = kcontext;
        this.pamSpace = pamSpace;
        this.pamProject = pamProject;
        this.configKey = configKey;
        this.jsonData = jsonData;
        
    }

    //---------------------------------------
    public GenericProcessConfigSetup(ProcessContext kcontext, String pamSpace, String pamProject, String configKey, String configPath, String configName, String jsonData) {
        this.kcontext = kcontext;
        this.pamSpace = pamSpace;
        this.pamProject = pamProject;
        this.configKey = configKey;
        this.configPath = configPath;
        this.configName = configName;
        this.jsonData = jsonData;
    }


    //---------------------------------------
    public void init() {

        logger.info("GenericProcessConfigSetup::init()");

        kcontext.setVariable("configKey", configKey);
        kcontext.setVariable("patchdata",patchJsonData);
        kcontext.setVariable("configPath",configPath);
        kcontext.setVariable("configName",configName);
        kcontext.setVariable("deviceName",deviceName);
        
        ProcessContextStatusUtil processContextStatusUtil = new ProcessContextStatusUtil();
        String statusdata = processContextStatusUtil.beforeRestWorkItemCall(pamSpace, pamProject, configKey, kcontext);
        logger.info("GenericProcessConfigSetup::" + configKey + " - statusdata = "+ statusdata);
        kcontext.setVariable("statusData", statusdata);
        
        ProcessContextPrinter.printAllVariables("GenericProcessConfigSetup::" + configKey, kcontext);
        
        
    }


    //---------------------------------------
    public void clear() {
        
    }


}