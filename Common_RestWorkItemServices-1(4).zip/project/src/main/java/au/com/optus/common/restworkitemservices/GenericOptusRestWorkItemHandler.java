package au.com.optus.common.restworkitemservices;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.client.HttpClient;
import org.jbpm.process.workitem.rest.RESTWorkItemHandler;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.jbpm.workflow.instance.WorkflowProcessInstance;
import org.jbpm.workflow.instance.WorkflowRuntimeException;
import org.jbpm.process.workitem.rest.RESTServiceException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.KieSession;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Arrays;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

import au.com.optus.common.restworkitemservices.MapToJsonProcessor;



//-------------------------------------------------------------
public class GenericOptusRestWorkItemHandler extends BaseOptusRestWorkItemHandler {

	private static final Logger logger = LoggerFactory.getLogger(GenericOptusRestWorkItemHandler.class);
	private static final String CONFIG_PATH = "/opt/kie/data/restconfigs";
	private static final String CONFIG_NAME = "RestCallConfigs.json";

	private static final String PARAM_CONFIGPATH = "configPath";
	private static final String PARAM_CONFIGNAME = "configName";

	private static final String PARAM_CONFIGKEY = "configKey";
	private static final String PARAM_JSONDATA = "jsonData";
	private static final String PARAM_DEVICENAME = "deviceName";
	private static final String PARAM_PATCHDATA = "patchData";

	private Map<String, Object> configCache = new HashMap<>();
	private JsonNodeProcessor jsonNodeProcessor = new JsonNodeProcessor();

	public GenericOptusRestWorkItemHandler() {
		super();
		handleLogs("GenericOptusRestWorkItemHandler", "initialized.");

	}
	
	
	//---------------------------------------------------------
	protected String getParameter(WorkItem workItem, String parameterName, String parameterDefault){
	    Object parameterValueObject = (Object) workItem.getParameter(parameterName);
	    String parameterValueStr = "";
	    
	    try {
    	    if(parameterValueObject != null )
    	    {
    	        if(parameterValueObject instanceof java.util.Map)
    	        {
    
                    handleLogs("getParameter", "parameterValueObject instanceof java.util.Map");
                    MapToJsonProcessor mapToJson = new MapToJsonProcessor();
                    parameterValueStr = mapToJson.convertMapToJson((java.util.Map)parameterValueObject);
                    return parameterValueStr;
    	        }
    	        else if(parameterValueObject instanceof String)
    	        {
    	            parameterValueStr = parameterValueObject.toString();
    	            if((!parameterValueStr.isEmpty() && !parameterValueStr.equals("")))
    	            {
                        handleLogs("getParameter",  parameterName + ":" + parameterValueStr);
                        return parameterValueStr;
    	            }
    	        }
    	        else
    	        {
    	            handleLogs("getParameter",  parameterValueObject + " is an unexpected type");
    	            handleLogs("getParameter",  parameterValueObject + ":" + parameterValueObject.toString()); 
    	        }
    
    	    }
	    }
	    catch(Exception e) {
            handleErrorLogs("getParameter", "exception thrown " + e.getMessage());	        
	    }
	    handleLogs("getParameter", "parameterName(" + parameterName + ") is null/empty");
	    handleLogs("getParameter", "returning " + parameterDefault);
	    return parameterDefault;
	}
	
	//---------------------------------------------------------
	protected JsonNode getJsonConfig(String path, String name, String key, String type) throws Exception
	{
	    
	    JsonNode restConfig = null;
	    
        restConfig = jsonNodeProcessor.loadJsonFileConfiguration(path, name, key, type);

		if(restConfig == null)
		{
		    throw new Exception("GenericOptusRestWorkItemHandler.jsonConfig exception for - Name: " + name + " configKey: " + key + " type: " + type);
		}

	
		handleLogs("executeWorkItem", "printing restConfig");
		jsonNodeProcessor.printJsonNode(restConfig);
		
		return restConfig;
    
	}

    //---------------------------------------------------------
	@Override
	public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
		try {

			logWorkItemDetails(workItem);

			handleLogs("executeWorkItem", "About to configureHandler");
			
			String configPATH = getParameter(workItem, PARAM_CONFIGPATH, CONFIG_PATH);
			handleLogs("executeWorkItem", "configPATH = " + configPATH);

			String configNAME = getParameter(workItem, PARAM_CONFIGNAME, CONFIG_NAME);
			handleLogs("executeWorkItem", "configNAME = " + configNAME);

			// Obtain endpoint configuration key
			String configKey = getParameter(workItem, PARAM_CONFIGKEY, "ConfigKey not set");
			handleLogs("executeWorkItem", "configKey = " + configKey);

			String jsonData = getParameter(workItem, PARAM_JSONDATA, "jsonData not set");
			handleLogs("executeWorkItem", "jsonData = " + jsonData);
			
			String deviceName = getParameter(workItem, PARAM_DEVICENAME, "deviceName not set");
			handleLogs("executeWorkItem", "deviceName = " + deviceName);

			//String configKey = (String) workItem.getParameter(PARAM_CONFIGKEY);
			//handleLogs("executeWorkItem", "configKey = " + configKey);

			//String jsonData = (String) workItem.getParameter(PARAM_JSONDATA);
			//handleLogs("executeWorkItem", "jsonData = " + jsonData);
			
			JsonNode restParameters = this.getJsonConfig(configPATH, configNAME, configKey, "parameters");
			JsonNode restConfig = this.getJsonConfig(configPATH, configNAME, configKey, "config");

			JsonNode mergedConfig = jsonNodeProcessor.mergeConfigs(workItem, restConfig,restParameters, jsonData);
			jsonNodeProcessor.printJsonNode(mergedConfig);

			jsonNodeProcessor.mapJsonNodeToWorkItem(workItem, mergedConfig);

			logWorkItemDetails(workItem);

			handleLogs("executeWorkItem", "About to invoke REST request1125...");

			super.executeWorkItem(workItem, manager);
			
        } catch (JsonMappingException jme) {
            handleErrorLogs("executeWorkItem", "JsonMappingException during REST invocation: " + jme.getMessage());
            handleException(jme);
		} catch (WorkflowRuntimeException wre) {
			handleErrorLogs("executeWorkItem", "WorkflowRuntimeException during REST invocation: " + wre.getMessage());
			handleException(wre);
		} catch (Exception e) {
			handleErrorLogs("executeWorkItem", "Exception during REST invocation: " + e.getMessage());
			handleException(e);
		}

		String response = (String) workItem.getResult(PARAM_RESULT);
		handleLogs("executeWorkItem", "result = " + response);
		int httpStatus = (int) workItem.getResult(PARAM_STATUS);
		handleLogs("executeWorkItem", "httpStatus converted = " + Integer.toString(httpStatus));
		String statusMsg = (String) workItem.getResult(PARAM_STATUS_MSG);
		handleLogs("executeWorkItem", "statusMsg = " + statusMsg);


		Map<String, Object> results = new HashMap<>();
		results.put("Result", response);
		results.put("HttpStatus", Integer.toString(httpStatus));
		results.put("StatusMsg", statusMsg);
		
	    manager.completeWorkItem(workItem.getId(), results);

		handleLogs("executeWorkItem", "REST request completed.");
	}

	@Override
	public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
		handleLogs("abortWorkItem", "Aborting work item: " + workItem.getName());
		super.abortWorkItem(workItem, manager);
	}


}
