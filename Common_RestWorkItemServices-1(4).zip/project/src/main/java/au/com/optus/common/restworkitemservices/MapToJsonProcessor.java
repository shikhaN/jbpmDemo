package au.com.optus.common.restworkitemservices;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class MapToJsonProcessor {
    private final ObjectMapper objectMapper;

    public MapToJsonProcessor() {
        this.objectMapper = new ObjectMapper();
    }

    public String convertMapToJson(Map<String, Object> map) throws JsonProcessingException {
        return objectMapper.writeValueAsString(map);
    }
}