package au.com.optus.common.restworkitemservices;

import com.fasterxml.jackson.core.JsonProcessingException;

import org.kie.api.runtime.process.ProcessContext;
import org.kie.internal.process.CorrelationKey;
import org.jbpm.process.instance.impl.ProcessInstanceImpl;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.KieSession;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.logging.Level;


//-------------------------------------------------------------------
public class PushUpdateProcessor {

    private static final Logger logger = LoggerFactory.getLogger(PushUpdateProcessor.class);

    private ProcessContext kcontext = null;
    private String businessProcessRef = "";  //business process id
    private String configKey = "";             //json config reference 

    //-------------------------------------------------------------------
    public PushUpdateProcessor(ProcessContext kcontext, String businessProcessRef, String configKey ) {
        this.kcontext = kcontext;
        this.businessProcessRef = businessProcessRef;
        this.configKey = configKey;
    }

    //-------------------------------------------------------------------
    private String createPushUpdateAnsibleData() {
        
        String jsonData = "";
        
        try{
            HashMap<String, Object> dataItems = new HashMap<>();
            dataItems.put("AnsibleData", "My Ansible Data");
        
            HashMap<String, Object> postdata = new HashMap<>();
            postdata.put("postdata", dataItems);     
            
            MapToJsonProcessor mapToJson = new MapToJsonProcessor();
            jsonData = mapToJson.convertMapToJson(postdata);
    
            logger.info(this.getClass().getName() + "::createPushUpdateAnsibleData() - jsonData" + jsonData);
        }
        catch(JsonProcessingException e)
        {
            logger.info(this.getClass().getName() + "::createPushUpdateAnsibleData() - exception thrown - " + e.getMessage());  
        }
        
        return jsonData;
        
    }

    //-------------------------------------------------------------------
    private String createPushUpdateProcessData() {

        String jsonData = "";
        
        try{        
            HashMap<String, Object> dataItems = new HashMap<>();
            dataItems.put("ProcessData", "My Process Data");
        
            HashMap<String, Object> postdata = new HashMap<>();
            postdata.put("postdata", dataItems);
     
            MapToJsonProcessor mapToJson = new MapToJsonProcessor();
            jsonData = mapToJson.convertMapToJson(postdata);
            
            logger.info(this.getClass().getName() + "::createPushUpdateProcessData() - jsonData" + jsonData);
        }
        catch(JsonProcessingException e)
        {
            logger.info(this.getClass().getName() + "::createPushUpdateProcessData() - exception thrown - " + e.getMessage());  
        }
        
        return jsonData;
        
    }

    //-------------------------------------------------------------------
    private String createPushUpdateTaskData() {
        
        String jsonData = "";
        
        try{         
            Long pamProcessInstanceID = kcontext.getProcessInstance().getId();
            String processIDStr = kcontext.getProcessInstance().getProcessId();
            
            HashMap<String, Object> dataItems = new HashMap<>();
            dataItems.put("TaskData", "{\"PushUpdateTaskData\": \"My First PushUpdateTaskData DataItem\"}");
            dataItems.put("second", "My Second Entry DataItem");
            dataItems.put("third", "My Third Entry DataItem");
        
            HashMap<String, Object> postdata = new HashMap<>();
            postdata.put("postdata", dataItems);
            
            MapToJsonProcessor mapToJson = new MapToJsonProcessor();
            jsonData = mapToJson.convertMapToJson(postdata);
            
            logger.info(this.getClass().getName() + "::createPushUpdateTaskData() - jsonData" + jsonData);
        }
        catch(JsonProcessingException e)
        {
            logger.info(this.getClass().getName() + "::createPushUpdateTaskData() - exception thrown - " + e.getMessage());  
        }
    
        return jsonData;
        
    }  


    //-------------------------------------------------------------------
    public void callAnsiblePushUpdate() throws RuntimeException {
        
        try {
            String jsonData = createPushUpdateAnsibleData();
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("configKey", configKey);
            parameters.put("jsonData", jsonData);
            
            kcontext.getKieRuntime().startProcess(businessProcessRef,parameters);  
        }
        catch (Exception e)
        {
            logger.info(this.getClass().getName() + "::callAnsiblePushUpdate()" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }
    
    //-------------------------------------------------------------------
    public void callProcessPushUpdate() throws RuntimeException {
        
        try {
            String jsonData = createPushUpdateProcessData();
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("configKey", configKey);
            parameters.put("jsonData", jsonData);
 
            logger.info(this.getClass().getName() + "::callProcessPushUpdate() - configKey = " + configKey);
            logger.info(this.getClass().getName() + "::callProcessPushUpdate() - jsonData = " + jsonData);
            
            kcontext.getKieRuntime().startProcess(businessProcessRef,parameters);  
        }
        catch (Exception e)
        {
            logger.info(this.getClass().getName() + "::callProcessPushUpdate()" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }    

    //-------------------------------------------------------------------
    public void callTaskPushUpdate() throws RuntimeException {
        
        logger.info(this.getClass().getName() + "::callTaskPushUpdate() entered");
        
        try {
            String jsonData = createPushUpdateTaskData();
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("configKey", configKey);
            parameters.put("jsonData", jsonData);
            
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - configKey = " + configKey);
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - jsonData = " + jsonData);
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - businessProcessRef = " + businessProcessRef);
            
            kcontext.getKieRuntime().startProcess(businessProcessRef,parameters);              
        }
        catch (Exception e)
        {
            logger.info(this.getClass().getName() + "::callTaskPushUpdate()" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
        
        logger.info(this.getClass().getName() + "::callTaskPushUpdate() - exited");
    }


    //-------------------------------------------------------------------
    public void callTaskPushUpdate(String statusData) throws RuntimeException {
        
        logger.info(this.getClass().getName() + "::callTaskPushUpdate(statusData) - entered");
        
        try {
            Map<String, Object> statusInfo = new HashMap<>();
            statusInfo.put("postdata", statusData);
            
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("configKey", configKey);
            parameters.put("jsonData", statusInfo);

            
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - configKey = " + configKey);
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - postData = " + statusData);
            logger.info(this.getClass().getName() + "::callTaskPushUpdate() - jsonData = " + statusData);
             logger.info(this.getClass().getName() + "::callTaskPushUpdate() -statusData- businessProcessRef = " + businessProcessRef);
            
            
            kcontext.getKieRuntime().startProcess(businessProcessRef,parameters);              
        }
        catch (Exception e)
        {
            logger.info(this.getClass().getName() + "::callTaskPushUpdate(statusData)" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }

        logger.info(this.getClass().getName() + "::callTaskPushUpdate(statusData) - exited");
    }    

    //-------------------------------------------------------------------
    public void callErrorPushUpdate(String statusData) throws RuntimeException {
        
        try {
            Map<String, Object> parameters = new HashMap<>();
            parameters.put("configKey", configKey);
            parameters.put("jsonData", statusData);
            parameters.put("postData", statusData);
            
            logger.info(this.getClass().getName() + "::callErrorPushUpdate() - configKey = " + configKey);
            logger.info(this.getClass().getName() + "::callErrorPushUpdate() - jsonData/statusData = " + statusData);
            logger.info(this.getClass().getName() + "::callErrorPushUpdate() - postData = " + statusData);
            
            kcontext.getKieRuntime().startProcess(businessProcessRef,parameters);              
        }
        catch (Exception e)
        {
            logger.info(this.getClass().getName() + "::callTaskPushUpdate()" + e.getMessage());
            throw new RuntimeException(e.getMessage());
        }
    }    


}