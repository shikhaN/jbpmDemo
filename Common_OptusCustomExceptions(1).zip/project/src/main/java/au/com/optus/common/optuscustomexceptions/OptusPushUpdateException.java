package au.com.optus.common.optuscustomexceptions;

public class OptusPushUpdateException extends RuntimeException {

    public OptusPushUpdateException(String message){
        super(message);
        System.err.println("OptusPushUpdateException::OptusPushUpdateException()");
    }

}
