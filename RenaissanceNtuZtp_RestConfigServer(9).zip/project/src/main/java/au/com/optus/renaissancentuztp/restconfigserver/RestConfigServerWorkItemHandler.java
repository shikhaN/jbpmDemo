package au.com.optus.renaissancentuztp.restconfigserver;

import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemManager;
import org.jbpm.process.workitem.core.AbstractLogOrThrowWorkItemHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;
import java.util.Deque;
import java.util.stream.Collectors;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.nio.file.StandardCopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Properties;

public class RestConfigServerWorkItemHandler extends AbstractLogOrThrowWorkItemHandler {

    
    private static final Logger logger = LoggerFactory.getLogger(RestConfigServerWorkItemHandler.class);
    
    private static final String PARAM_CONFIGDIRPATH = "configDirectoryPath";

    @Override
    public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
        
        logger.info("RestConfigServerWorkItemHandler::executeWorkItem()");
 
        String resourcesDirectory = "resources/";
        String configDirectoryPath = "/opt/kie/data/restconfigs";
        Map<String, Object> results = new HashMap<>();
        
        try {
            //create directory if necessary
            String configPATH = (String)workItem.getParameter(PARAM_CONFIGDIRPATH);
          
            if(configPATH != null && !configPATH.isEmpty()){
                configDirectoryPath = configPATH;
            }
            
            
            Path directoryPath = Paths.get(configDirectoryPath);
            
            if(directoryPath != null && !Files.exists(directoryPath)) {
                try {
                    Files.createDirectories(directoryPath);
                    logger.info("RestConfigServerWorkItemHandler::executeWorkItem() - created " + configDirectoryPath + " directory.");
                } 
                catch (IOException e) {
                    logger.info("RestConfigServerWorkItemHandler::executeWorkItem() - failed to create " + configDirectoryPath + " directory." + e.getMessage());
                }
                
            }
            else {
                logger.info("RestConfigServerWorkItemHandler::executeWorkItem() - " + configDirectoryPath + " directory already exists.");
            }
            
            
            
            // Load the config-index.properties file
            Properties configIndex = new Properties();
            try (InputStream is = this.getClass().getClassLoader().getResourceAsStream("config-index.properties")) {
                if (is == null) {
                    throw new RuntimeException("config-index.properties file not found in resources.");
                }
                configIndex.load(is);
            }
            
            // Iterate over each entry in the properties file
            for (String key : configIndex.stringPropertyNames()) {
                String resourcePath = configIndex.getProperty(key);
                InputStream resourceStream = this.getClass().getClassLoader().getResourceAsStream(resourcePath);
                if (resourceStream != null) {
                    Files.copy(resourceStream, Paths.get(configDirectoryPath, key), StandardCopyOption.REPLACE_EXISTING);
                    resourceStream.close(); // Ensure the stream is closed after use
                    logger.info("RestConfigServerWorkItemHandler::executeWorkItem() - config file - " + resourcePath +  " copied");
                } else {
                    logger.info("RestConfigServerWorkItemHandler::executeWorkItem() Could not find resource: " + resourcePath);
                }
            }
        
        
            results.put("Result", "completed");
            
            // Use the output in your jBPM process
            manager.completeWorkItem(workItem.getId(), results);
            
        } catch (Exception e) {
            logger.info("RestConfigServerWorkItemHandler::executeWorkItem() - exception thrown " + e.getMessage());
            e.printStackTrace();
            // Handle any exceptions, possibly aborting the work item
            results.put("Result", e.getMessage());
            manager.abortWorkItem(workItem.getId());
        }
    }

    //------------------------------------------------------------------
    @Override
    public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
        logger.info("RestConfigServerWorkItemHandler::abortWorkItem()");

    }
}

