package au.com.optus.common.commonworkitemhandlers;

import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.WorkItemHandler;
import org.kie.api.runtime.process.WorkItemManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collector;


public class EmbeddedPythonWorkItemHandler implements WorkItemHandler {
    
    private final PythonScript pythonScript = new PythonScript();
    
    private static class PythonScript {
        String getScriptContent() {
            return "print('Python says helloWorld')";
        }
    }

    @Override
    public void executeWorkItem(WorkItem workItem, WorkItemManager manager) {
        // Retrieve the script content from the work item parameters - using "scriptPath".
        System.out.println("EmbeddedPythonWorkItemHandler::executeWorkItem()");
        String scriptContent = (String) pythonScript.getScriptContent();

        // Save the script to a temporary file
        try {

            // Execute the Python script
            ProcessBuilder processBuilder = new ProcessBuilder("python", ",-c", scriptContent);
            Process process = processBuilder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            StringBuilder output = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            int exitCode = process.waitFor();
            
            if (exitCode != 0) {
                throw new RuntimeException("Python script exited with error code: " + exitCode);
            }

            Map<String, Object> results = new HashMap<>();
            results.put("Result", output.toString().trim());
            
            System.out.println("EmbeddedPythonWorkItemHandler::executeWorkItem() - script result = " + output.toString().trim());
            
            // Use the output in your jBPM process
            manager.completeWorkItem(workItem.getId(), results);
            
        } catch (Exception e) {
            System.out.println("EmbeddedPythonWorkItemHandler::executeWorkItem() - exception thrown " + e.getMessage());
            e.printStackTrace();
            manager.abortWorkItem(workItem.getId());
            throw new RuntimeException("Error executing EmbeddedPythonWorkItemHandler::executeWorkItem() python script - " + scriptContent , e);
        }
    }

    @Override
    public void abortWorkItem(WorkItem workItem, WorkItemManager manager) {
        // Add aborting logic if needed
    }
}