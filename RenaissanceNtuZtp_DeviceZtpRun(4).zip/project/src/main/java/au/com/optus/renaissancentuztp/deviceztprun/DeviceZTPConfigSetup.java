package au.com.optus.renaissancentuztp.deviceztprun;

import org.kie.api.runtime.process.ProcessContext;
import org.kie.api.runtime.process.ProcessInstance;
import au.com.optus.common.restworkitemservices.ProcessContextStatusUtil;
import au.com.optus.common.restworkitemservices.ProcessContextPrinter;
import au.com.optus.common.restworkitemservices.GenericProcessConfigSetup;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//---------------------------------------------
public class DeviceZTPConfigSetup extends GenericProcessConfigSetup {
    
    private static final Logger logger = LoggerFactory.getLogger(DeviceZTPConfigSetup.class);

    //---------------------------------------
    public DeviceZTPConfigSetup(ProcessContext kcontext, String pamSpace, String pamProject, String configKey, String jsonData) {
        super(kcontext, pamSpace, pamProject, configKey, jsonData);
    }

    //---------------------------------------
    public DeviceZTPConfigSetup(ProcessContext kcontext, String pamSpace, String pamProject, String configKey, String configPath, String configName, String jsonData) {
        super(kcontext, pamSpace, pamProject, configKey, configPath, configName, jsonData);
    }


}
