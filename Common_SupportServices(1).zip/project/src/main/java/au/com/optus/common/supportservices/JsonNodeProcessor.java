package au.com.optus.common.supportservices;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import org.kie.api.runtime.process.WorkItem;
import org.kie.api.runtime.process.ProcessContext;
import org.kie.api.runtime.process.ProcessInstance;
import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//------------------------------
public class JsonNodeProcessor {

    private static final Logger logger = LoggerFactory.getLogger(JsonNodeProcessor.class);
    private static final String DEBUG_PROJECT_PREFIX = "JsonNodeProcessor";
    private final Map<String, Object> configCache = new ConcurrentHashMap<>();
    private final Map<String, Long> lastModifiedMap = new ConcurrentHashMap<>();
    private MapToJsonProcessor mapToJson = new MapToJsonProcessor();

    //------------------------------
    public JsonNodeProcessor() {}


    //------------------------------
    public JsonNode loadJsonConfiguration(String configPath, String configName, String configKey, String type) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Path filePath = Paths.get(configPath, configName);
        long lastModifiedTime = Files.getLastModifiedTime(filePath).toMillis();

        String cacheKey = configName + "-" + configKey + "-" + type;        
        if (configCache.containsKey(cacheKey) && lastModifiedMap.getOrDefault(cacheKey, 0L) >= lastModifiedTime) {
            logger.debug(DEBUG_PROJECT_PREFIX + "::loadConfiguration() - retrieving from cache");
            return (JsonNode) configCache.get(cacheKey);
        }

        String jsonString = new String(Files.readAllBytes(filePath));
        JsonNode jsonTypeNode = extractJsonTypeNode(objectMapper, jsonString, configKey, type);

        configCache.put(cacheKey, jsonTypeNode);
        lastModifiedMap.put(cacheKey, lastModifiedTime);
        return jsonTypeNode;
    }


    //------------------------------
    private JsonNode extractJsonTypeNode(ObjectMapper objectMapper, String jsonString, String configKey, String type) {
        try {
            JsonNode jsonNameNode = objectMapper.readTree(jsonString);
            if (jsonNameNode.has(configKey)) {
                JsonNode configKeyNode = jsonNameNode.get(configKey);
                return configKeyNode.has(type) ? configKeyNode.get(type) : null;
            }
        } catch (IOException e) {
            logger.error(DEBUG_PROJECT_PREFIX + "::extractJsonTypeNode() - IOException", e);
        }
        return null;
    }


    //------------------------------
    public void mapJsonNodeToWorkItem(WorkItem workItem, JsonNode jsonNode) {
        Iterator<Map.Entry<String, JsonNode>> fields = jsonNode.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> field = fields.next();
            workItem.getParameters().put(field.getKey(), field.getValue().asText());
        }
    }

    //------------------------------
    public JsonNode mergeConfigs(WorkItem workItem, JsonNode baseConfig, JsonNode dynamicData, String jsonString) throws JsonMappingException, JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode mergedConfig = (ObjectNode) baseConfig;
        processDynamicData(workItem, dynamicData, mergedConfig, jsonString);
        return mergedConfig;
    }
    
    
    //------------------------------
    private void processDynamicData(WorkItem workItem, JsonNode dynamicData, ObjectNode mergedConfig, String jsonString) throws JsonMappingException {
        
            dynamicData.forEach(item -> {
                String type = item.get("type").asText();
                String key = item.get("key").asText();
                switch (type) {
                    case "environment":
                        processEnvironmentVariable(key, mergedConfig);
                        break;
                    case "jsonfile":
                        try {
                            processJsonFileData(item, key, jsonString, mergedConfig);
                        } catch (Exception e) {
                            logger.error(DEBUG_PROJECT_PREFIX + "::processDynamicData() - Exception", e);
                        }
                        break;
                    case "workitem":
                        try {
                            processProcessVariable(key, mergedConfig, workItem);
                        } catch (Exception e) {
                            logger.error(DEBUG_PROJECT_PREFIX + "::processDynamicData() - Exception", e);
                        }
                        break;
                    default:
                        logger.warn(DEBUG_PROJECT_PREFIX + "::processDynamicData() - Unknown type: " + type);
                }
            });

    }

    //------------------------------
    private void processEnvironmentVariable(String key, ObjectNode mergedConfig) {
        String envValue = System.getenv(key);
        if (envValue != null) {
            replacePlaceholder(mergedConfig, "{" + key + "}", envValue);
        }
    }
    
    
    //------------------------------
    private void processProcessVariable(String key, ObjectNode mergedConfig, WorkItem workItem) throws JsonProcessingException {
        Object processValue = (Object)workItem.getParameter(key);
        if(processValue != null) {
            if(processValue instanceof String) {
                replacePlaceholder(mergedConfig, "{" + key + "}", (String)processValue);
            }
            else if(processValue instanceof Map) {
                String jsonValue = mapToJson.convertMapToJson((Map)processValue);
                replacePlaceholder(mergedConfig, "{" + key + "}", jsonValue);
            }
            else {
                logger.info(DEBUG_PROJECT_PREFIX + "::processProcessVariable() - processVariable's processValue is of an unexpected type");             
            }
        }
        else {
            logger.info(DEBUG_PROJECT_PREFIX + "::processProcessVariable() - processVariable(" + key + ") does not exist");
        }

    }
        
    
    //------------------------------
    private void processJsonFileData(JsonNode item, String key, String jsonString, ObjectNode mergedConfig) throws JsonMappingException {
        try {
            //JsonNode jsonNode = new ObjectMapper().readTree(jsonString);
            JsonToMapProcessor jsonMap = new JsonToMapProcessor(jsonString);
            String jsonValue = null;
            Object itemValue = (Object) (jsonMap.getValuesForKeyPath(item.get("varPath").asText()).get(0));    
            if(itemValue != null) {
                if(itemValue instanceof Map){
                    logger.info(DEBUG_PROJECT_PREFIX + "::processJsonFileData() - itemValue is a Map");
                    jsonValue = mapToJson.convertMapToJson((Map)itemValue);
                }
                else if(itemValue instanceof String) {
                    jsonValue = (String)itemValue;
                } 
                else {
                    logger.info(DEBUG_PROJECT_PREFIX + "::processJsonFileData() - itemValue is an unexpected type"); 
                }
            } 
                
            //String jsonValue = jsonNode.at(item.get("varPath").asText()).asText();
            if (jsonValue != null && !jsonValue.isEmpty()) {
                replacePlaceholder(mergedConfig, "{" + key + "}", jsonValue);
            } else {
                logger.debug(DEBUG_PROJECT_PREFIX + "::processJsonFileData() - Key not found: " + key);
            }
        } catch (Exception e) {
            logger.error(DEBUG_PROJECT_PREFIX + "::processJsonFileData() - Exception", e);
            throw new JsonMappingException("Error processing JSON file data: " + e.getMessage(), e);
        }
    }

    //------------------------------
    private void replacePlaceholder(ObjectNode node, String placeholder, String value) {
        node.fields().forEachRemaining(field -> {
            JsonNode fieldValue = field.getValue();
            if (fieldValue.isTextual() && fieldValue.asText().contains(placeholder)) {
                node.put(field.getKey(), fieldValue.asText().replace(placeholder, value));
            } else if (fieldValue.isObject()) {
                replacePlaceholder((ObjectNode) fieldValue, placeholder, value);
            }
        });
    }
    
    //------------------------------
    public void printJsonNode(JsonNode jsonNode) {
        logger.info(DEBUG_PROJECT_PREFIX + "::printJsonNode() - " + jsonNode);
    }
}