package au.com.optus.common.supportservices;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class JsonToMapProcessor {

   private static final Logger logger = LoggerFactory.getLogger(JsonToMapProcessor.class);
   private Map<String, Object> dataMap;


   //---------------------
   public JsonToMapProcessor(String jsonData) throws Exception {
       logger.info("JsonToMapProcessor::JsonToMapProcessor() - jsonData = " + jsonData);
       ObjectMapper objectMapper = new ObjectMapper();
       this.dataMap = objectMapper.readValue(jsonData, HashMap.class);
       logger.info("JsonToMapProcessor::JsonToMapProcessor() leaving");
   }

   //---------------------
   public Map<String, Object> getDataMap() {
       return dataMap;
   }

   //---------------------
   public Object getValue(String key) {
       return deepFind(this.dataMap, key);
   }

   //---------------------
   public List<String> getAllKeys() {
       return extractKeys(this.dataMap, "");
   }

   //---------------------
   private Object deepFind(Map<String, Object> map, String key) {
       if (map.containsKey(key)) {
           return map.get(key);
       } else {
           for (Map.Entry<String, Object> entry : map.entrySet()) {
               if (entry.getValue() instanceof Map) {
                   Object result = deepFind((Map<String, Object>) entry.getValue(), key);
                   if (result != null) {
                       return result;
                   }
               }
           }
       }
       return null;
   }

   //---------------------
   private List<String> extractKeys(Map<String, Object> map, String prefix) {
       return map.entrySet().stream()
           .flatMap(entry -> {
               if (entry.getValue() instanceof Map) {
                   return extractKeys((Map<String, Object>) entry.getValue(), prefix + entry.getKey() + ".").stream();
               } else if (entry.getValue() instanceof List && !((List) entry.getValue()).isEmpty() && ((List) entry.getValue()).get(0) instanceof Map) {
                   List<Map<String, Object>> list = (List<Map<String, Object>>) entry.getValue();
                   return list.stream().flatMap(innerMap -> extractKeys(innerMap, prefix + entry.getKey() + ".").stream());
               } else {
                   return Stream.of(prefix + entry.getKey());
               }
           })
           .collect(Collectors.toList());
   }
   
   
  //---------------------
   public void printContents(LinkedHashMap<String, Object> map) {
        String contents = map.entrySet().stream()
                .map(entry -> entry.getKey() + ": " + entry.getValue())
                .collect(Collectors.joining("\n"));
        logger.debug("JsonToMapProcessor::printContents(LinkedHashMap) - " + contents);
    }
    
   //---------------------    
   public void printContents() {
       
        String contents = dataMap.entrySet().stream()
                .map(entry -> entry.getKey() + ": " + entry.getValue())
                .collect(Collectors.joining("\n"));
        logger.debug("JsonToMapProcessor::printContents() - " + contents);
    }  

   //---------------------    
   public void printAllKeys() {
       logger.debug("JsonToMapProcessor::printAllKeys()");
        printKeysFromMap(this.dataMap, "");
   }

   //---------------------   
    private void printKeysFromMap(Map<String, Object> map, String prefix) {
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            logger.debug(prefix + key);
            if (value instanceof Map) {
                printKeysFromMap((Map<String, Object>) value, prefix + key + ".");
            }
            
            if (value instanceof List)
            {
                for (Object listItem: (List<?>)value)
                {
                    if(listItem instanceof Map)
                    {
                      printKeysFromMap((Map<String, Object>) listItem, prefix + key + ".");  
                    }
                }
            }

        }
    }

   //---------------------   
    public List<Object> getValuesForKeyPath(String keyPath) {
        logger.info("JsonToMapProcessor::getValuesForKeyPath() - keyPath = " + keyPath);
        List<Object> results = new ArrayList<>();
        if (dataMap != null && !dataMap.isEmpty()) {
            String[] parts = keyPath.split("\\.");
            getValuesFromMapForKeyPath(dataMap, parts, 0, results);
        }
        logger.info("JsonToMapProcessor::getValuesForKeyPath() - results = " + results);
        return results;
    }
 
   //---------------------      
    private void getValuesFromMapForKeyPath(Map<String, Object> map, String[] keyParts, int depth, List<Object> results) {
        Object value = map.get(keyParts[depth]);
    
        if (value == null) return;
    
        // If we reached the end of the key path, add the found value to results
        if (depth == keyParts.length - 1) {
            results.add(value);
        } else {
            // If value is another map, do a recursive call
            if (value instanceof Map) {
                getValuesFromMapForKeyPath((Map<String, Object>) value, keyParts, depth + 1, results);
            }
    
            // If value is a list, iterate over it
            if (value instanceof List) {
                for (Object listItem : (List<?>) value) {
                    if (listItem instanceof Map) {
                        getValuesFromMapForKeyPath((Map<String, Object>) listItem, keyParts, depth + 1, results);
                    }
                }
            }
        }
    }


}
