package au.com.optus.common.supportservices;

import org.kie.api.runtime.process.ProcessContext;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.runtime.process.WorkflowProcessInstance;
import org.jbpm.workflow.instance.impl.WorkflowProcessInstanceImpl;
import org.jbpm.process.core.context.variable.VariableScope;
import org.jbpm.process.instance.context.variable.VariableScopeInstance;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProcessContextPrinter {
    
    private static final Logger logger = LoggerFactory.getLogger(ProcessContextPrinter.class);

    public static void printAllVariables(String processName, ProcessContext kcontext) {
        
        logger.info("------------------------------------");
        logger.info(processName + "::printAllVariables()");
        
        ProcessInstance processInstance = kcontext.getProcessInstance();
        if (processInstance instanceof WorkflowProcessInstanceImpl) {
            WorkflowProcessInstanceImpl workflowProcessInstance = (WorkflowProcessInstanceImpl) processInstance;
            VariableScopeInstance variableScopeInstance = (VariableScopeInstance)
                workflowProcessInstance.getContextInstance(VariableScope.VARIABLE_SCOPE);

            Map<String, Object> variables = variableScopeInstance.getVariables();

            if (variables != null && !variables.isEmpty()) {
                logger.info("Variables in kcontext:");
                for (Map.Entry<String, Object> entry : variables.entrySet()) {
                    logger.info(entry.getKey() + " = " + entry.getValue());
                }
            } else {
                logger.info("No variables found in kcontext.");
            }
        } else {
            logger.info("Process instance is not a WorkflowProcessInstance.");
        }
    }

}