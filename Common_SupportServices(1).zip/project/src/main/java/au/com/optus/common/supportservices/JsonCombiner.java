package au.com.optus.common.supportservices;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

//------------------------------------------
public class JsonCombiner {

    //------------------------------------------
    public String combineJson(String json1, String json2, String root1, String root2) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        // Parse the JSON strings
        JsonNode node1 = mapper.readTree(json1);
        JsonNode node2 = mapper.readTree(json2);

        // Create a new root object and put both JSON objects under it
        ObjectNode combined = mapper.createObjectNode();
        combined.set(root1, node1);
        combined.set(root2, node2);

        // Convert back to JSON string
        return mapper.writeValueAsString(combined);
    }
}
